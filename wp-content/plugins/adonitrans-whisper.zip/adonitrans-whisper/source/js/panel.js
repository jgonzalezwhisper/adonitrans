jQuery(document).ready(function($) {

    $.validator.addMethod(
        "checkPassword",
        function(value, element) {
            let hasNumber = /\d/.test(value);
            let hasSpecialChar = /[*\-_.\/!¿?]/.test(value);
            let hasUpperCase = /[A-Z]/.test(value);
            let lengthValid = value.length >= 8 && value.length <= 15;

            $("li:contains('Entre 8 y 15 carácteres')").toggleClass(
                "tachado",
                lengthValid
            );
            $("li:contains('Un número')").toggleClass("tachado", hasNumber);
            $("li:contains('Un carácter especial (*-_./!¿?)')").toggleClass(
                "tachado",
                hasSpecialChar
            );
            $("li:contains('Una mayúscula')").toggleClass("tachado", hasUpperCase);

            return (
                this.optional(element) ||
                (hasNumber && hasSpecialChar && hasUpperCase && lengthValid)
            );
        },
        "La contraseña debe cumplir con los requisitos."
    );

    var ps = new PerfectScrollbar('#informacion', {
        wheelSpeed: 2,
        wheelPropagation: true,
        minScrollbarLength: 20
    });

    $("#lateral ul li[data-action]").on("click", function() {

        var action = $(this).data("action");
        if (action === "logout") {
            return;
        }
        $('body').addClass('actloader');
        var fileUrl = panelAjax.plugin_url + "includes/parts/panel/" + action + ".php";

        $.ajax({
            url: fileUrl,
            method: "GET",
            success: function(response) {
                $('body').removeClass('actloader');
                $("#informacion").html(response);
                if (action == 'usuario') {
                    initUsuarios();
                }
                if (action == 'vehiculo') {
                    initVehiculos();
                }

            },
            error: function() {
                $('body').removeClass('actloader');
                $("#informacion").html("<p>Error al cargar el contenido. Intenta nuevamente.</p>");
            }
        });
    });
});

function checkPassword(value) {
    let hasNumber = /\d/.test(value);
    let hasSpecialChar = /[*\-_.\/!¿?]/.test(value);
    let hasUpperCase = /[A-Z]/.test(value);
    let lengthValid = value.length >= 8 && value.length <= 15;

    // Actualizar la UI de los requisitos de la contraseña
    jQuery("li:contains('Entre 8 y 15 carácteres')").toggleClass("tachado", lengthValid);
    jQuery("li:contains('Un número')").toggleClass("tachado", hasNumber);
    jQuery("li:contains('Un carácter especial (*-_./!¿?)')").toggleClass("tachado", hasSpecialChar);
    jQuery("li:contains('Una mayúscula')").toggleClass("tachado", hasUpperCase);

    // Devolver el resultado de la validación
    return hasNumber && hasSpecialChar && hasUpperCase && lengthValid;
}

function initUsuarios() {
    jQuery('#table-usuarios').DataTable({
        language: {
            url: 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/es-ES.json'
        }
    });
    jQuery('#select-rolesusuario').select2({
        placeholder: "Selecciona un rol",
        allowClear: true,
        width: '100%'
    });
}

function initVehiculos() {
    jQuery('#table-vehiculos').DataTable({
        language: {
            url: 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/es-ES.json'
        }
    });

    jQuery('#tipo_de_vehiculo, #propietario_de_vehiculo').select2({
        placeholder: "Selecciona un Valor",
        allowClear: true,
        width: '100%'
    });
}