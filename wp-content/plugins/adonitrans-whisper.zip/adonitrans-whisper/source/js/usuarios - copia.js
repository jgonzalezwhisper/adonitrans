jQuery(document).ready(function($) {

    function generarContrasena() {
        var longitud = 12; // Longitud aleatoria entre 8 y 12 caracteres
        var caracteresEspeciales = '#$%&/=!';
        var mayusculas = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        var minusculas = 'abcdefghijklmnopqrstuvwxyz';
        var numeros = '0123456789';
        var todosCaracteres = mayusculas + minusculas + numeros + caracteresEspeciales;

        var contrasena = '';
        var numerosUsados = 0;

        // Garantizar que haya al menos dos números no seguidos
        while (numerosUsados < 2) {
            contrasena = '';
            numerosUsados = 0;

            // Generar la contraseña aleatoria
            for (var i = 0; i < longitud; i++) {
                var caracter;
                if (i === 0 || Math.random() < 0.7) {
                    caracter = todosCaracteres.charAt(Math.floor(Math.random() * todosCaracteres.length));
                } else {
                    caracter = numeros.charAt(Math.floor(Math.random() * numeros.length));
                    if (i > 0 && contrasena[i - 1] === caracter) {
                        i--; // Si es un número seguido, lo volvemos a intentar
                        continue;
                    }
                    numerosUsados++;
                }
                contrasena += caracter;
            }
        }

        // Asegurarse de que tenga al menos una letra mayúscula
        if (!/[A-Z]/.test(contrasena)) {
            var mayuscula = mayusculas.charAt(Math.floor(Math.random() * mayusculas.length));
            contrasena = contrasena.slice(0, Math.floor(Math.random() * contrasena.length)) + mayuscula + contrasena.slice(Math.floor(Math.random() * contrasena.length) + 1);
        }

        // Asegurarse de que tenga al menos un carácter especial
        if (!/[#$%&/=!]/.test(contrasena)) {
            var especial = caracteresEspeciales.charAt(Math.floor(Math.random() * caracteresEspeciales.length));
            contrasena = contrasena + especial;
        }

        return contrasena;
    }

    // Mostrar/Ocultar campos adicionales según el rol seleccionado
    function toggleFieldsByRole(role) {
        const extraFieldsContainer = $('#extra-fields-container');
        const paymentFieldsContainer = $('#payment-fields-container');

        // Ocultar todo por defecto
        extraFieldsContainer.hide();
        paymentFieldsContainer.hide();

        if (role) {
            extraFieldsContainer.show();

            if (role === 'propietario_vehiculo' || role === 'conductor') {
                paymentFieldsContainer.show();
            }
        }
    }

    $(document).on('click', '#wrap-usuarios .wrap-listado-usuarios .edit-user', function(event) {

        $('body').addClass('actloader');
        var user_id = $(this).data('userid');

        $("#password").text('').val('').removeAttr("required");
        $("#user-form #user-id").val(user_id);

        // Enviar la solicitud AJAX para obtener los datos del usuario
        $.ajax({
            url: usuarioAjax.ajaxurl,
            method: 'POST',
            data: {
                action: 'load_user_data',
                user_id: user_id
            },
            success: function(response) {
                if (response.success) {

                    $('#user-id').val(user_id);
                    $('#first-name').val(response.data.first_name);
                    $('#last-name').val(response.data.last_name);
                    $('#user-email').val(response.data.email);
                    $('#select-rolesusuario').val(response.data.role).trigger('change');
                    $('#user-state').val(response.data.meta_estado).trigger('change');

                    toggleFieldsByRole(response.data.role);

                    $('#user-cedula').val(response.data.meta_cedula);
                    $('#user-telefono').val(response.data.meta_telefono);
                    $('#user-direccion').val(response.data.meta_direccion);

                    var info_pago = response.data.meta_pagos; 

                    // Comprobamos si el array tiene elementos y si los campos dentro de ese objeto no están vacíos
                    if (Array.isArray(info_pago) && info_pago.length > 0) {
                        var validado = true;

                        $.each(info_pago, function(index, item) {
                            if (!item.nombre_banco || !item.no_cuenta || !item.tipo_de_cuenta) {
                                validado = false;
                                return false;
                            }
                        });

                        if (validado) {    

                            $('.payment-row input').val('').text('');                       

                            // Llenar la primera fila con los datos del primer objeto
                            var firstPaymentRow = $('.payment-row').first();
                            firstPaymentRow.find('input[name="nombre_banco[]"]').val(info_pago[0].nombre_banco);
                            firstPaymentRow.find('input[name="no_cuenta[]"]').val(info_pago[0].no_cuenta);
                            firstPaymentRow.find('select[name="tipo_de_cuenta[]"]').val(info_pago[0].tipo_de_cuenta);

                            // Si hay más de un objeto en el array, clonar las filas adicionales y llenarlas
                            if (info_pago.length > 1) {
                                for (var i = 1; i < info_pago.length; i++) {
                                    // Clonar la última fila de pago
                                    var newRow = $('.payment-row').last().clone();

                                    // Limpiar los campos de la nueva fila
                                    newRow.find('input').val('');
                                    newRow.find('select').val('');

                                    // Llenar los campos con los datos del siguiente objeto
                                    newRow.find('input[name="nombre_banco[]"]').val(info_pago[i].nombre_banco);
                                    newRow.find('input[name="no_cuenta[]"]').val(info_pago[i].no_cuenta);
                                    newRow.find('select[name="tipo_de_cuenta[]"]').val(info_pago[i].tipo_de_cuenta);

                                    // Añadir un enlace para remover la fila
                                    newRow.append('<a href="#" class="remove-payment-row">✖</a>');

                                    // Insertar el nuevo clon en el contenedor
                                    $('#repeater-payment-fields').append(newRow);
                                }
                            }
                            $('#payment-fields-container').show();
                        } 
                    }else{
                        $('.payment-row input').val('').text('');
                    }

                    $('#wrap-usuarios .wrap-gestion-usuarios button[type="submit"]').text('Editar Usuario');
                    $('#wrap-usuarios .wrap-gestion-usuarios .title').text('Editar Usuario');
                    $("#wrap-usuarios .wrap-listado-usuarios").hide();
                    $("#wrap-usuarios .wrap-gestion-usuarios").show();
                    $('body').removeClass('actloader');
                } else {
                    $('body').removeClass('actloader');
                    // Si la respuesta es exitosa, mostrar mensaje de éxito
                    Swal.fire({
                        title: 'Algo ha ocurrido!',
                        text: response.data.message,
                        icon: 'error',
                        confirmButtonText: 'Aceptar'
                    });
                }
            }
        });
    });

    $(document).on('click', '#wrap-usuarios .wrap-listado-usuarios .delete-user', function(event) {
        event.preventDefault();

        // Obtener el ID del usuario desde el botón
        var userId = $(this).data('userid');

        // Mostrar la confirmación con SweetAlert
        Swal.fire({
            title: '¿Estás seguro?',
            text: 'Esta acción eliminará al usuario de forma permanente.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                // Si el usuario confirma, realiza la solicitud AJAX
                $.ajax({
                    url: usuarioAjax.ajaxurl, // La URL de admin-ajax.php en WordPress
                    method: 'POST',
                    data: {
                        action: 'delete_user', // Acción personalizada en WordPress
                        user_id: userId
                    },
                    success: function(response) {
                        if (response.success) {
                            // Mostrar mensaje de éxito
                            Swal.fire(
                                '¡Eliminado!',
                                'El usuario ha sido eliminado exitosamente.',
                                'success'
                            ).then(() => {
                                var fileUrl = usuarioAjax.plugin_url + "includes/parts/panel/usuario.php";

                                $.ajax({
                                    url: fileUrl,
                                    method: "GET",
                                    success: function(response) {
                                        $("#informacion").html(response);
                                        initUsuarios();
                                    },
                                    error: function() {
                                        $("#informacion").html("<p>Error al cargar el contenido. Intenta nuevamente.</p>");
                                    }
                                });
                            });

                        } else {
                            // Mostrar mensaje de error
                            Swal.fire(
                                'Error',
                                response.data.message || 'No se pudo eliminar el usuario.',
                                'error'
                            );
                        }
                    },
                    error: function() {
                        // Mostrar mensaje de error si AJAX falla
                        Swal.fire(
                            'Error',
                            'Hubo un problema al intentar eliminar el usuario.',
                            'error'
                        );
                    }
                });
            }
        });
    });

    $(document).on('click', '#crear-usuario', function(event) {
        event.preventDefault();

        $('#user-form')[0].reset();
        $('#wrap-usuarios .wrap-gestion-usuarios button[type="submit"]').text('Crear Usuario');

        $("#wrap-usuarios .wrap-listado-usuarios").hide();
        $("#wrap-usuarios .wrap-gestion-usuarios").show();
    });

    $(document).on('click', '#wrap-usuarios .wrap-gestion-usuarios button[type="button"]', function(event) {
        $('#user-form')[0].reset();
        $("#user-id").text('').val('');
        $('#select-rolesusuario').val(null).trigger('change');
        $("#wrap-usuarios .wrap-gestion-usuarios").hide();
        $("#wrap-usuarios .wrap-listado-usuarios").show();
    });

    // Evento al cambiar el rol
    $(document).on('change', '#select-rolesusuario', function(event) {
        event.preventDefault();

        const selectedRole = $(this).val();
        toggleFieldsByRole(selectedRole);
    });

    $(document).on('click', '#add-payment-row', function(e) {
        e.preventDefault(); // Evita el comportamiento predeterminado del enlace

        // Clonar la última fila de pago
        var newRow = $('.payment-row').last().clone();

        newRow.find('input').val('');
        newRow.find('select').val('');

        newRow.find('.remove-payment-row').remove();
        newRow.append('<a href="#" class="remove-payment-row">✖</a>');

        // Insertar el nuevo clon en el contenedor
        $('#repeater-payment-fields').append(newRow);
    });

    // Al hacer clic en el icono de eliminar
    $(document).on('click', '.remove-payment-row', function(e) {
        e.preventDefault(); // Evita el comportamiento predeterminado del enlace
        $(this).closest('.payment-row').remove(); // Elimina la fila de pago
    });

    $(document).on('click', '#generate-password', function(e) {
        e.preventDefault(); // Evita el comportamiento predeterminado del enlace
        var contrasenaGenerada = generarContrasena();
        $('#password').val(contrasenaGenerada); // Asignar la contraseña generada al campo de entrada
    });

     // Controlar el evento blur del campo #password
    $(document).on('blur', '#user-form #password', function(e) {
        let passwordValid = checkPassword($(this).val());
        let userIdEmpty = !$("#user-id").val(); // Validar si el campo user-id está vacío

        // Habilitar o deshabilitar el botón según la validación
        if (!passwordValid || userIdEmpty) {
            $("#user-form button[type='submit']").prop("disabled", true); // Inhabilitar el botón
        } else {
            $("#user-form button[type='submit']").prop("disabled", false); // Habilitar el botón
        }
    });

    // Enviar formulario vía AJAX
    $(document).on('submit', '#user-form', function(e) {
        e.preventDefault();

        $('body').addClass('actloader');

        // Recoger los datos del formulario
        var formData = new FormData(this);
        formData.append('action', 'create_user');

        // Realizar la petición AJAX
        $.ajax({
            url: usuarioAjax.ajaxurl,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                $('body').removeClass('actloader');
                if (response.success) {
                    // Si la respuesta es exitosa, mostrar mensaje de éxito
                    Swal.fire({
                        title: '¡Éxito!',
                        text: response.data.message,
                        icon: 'success',
                        confirmButtonText: 'Aceptar'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $('#user-form')[0].reset();

                            var fileUrl = usuarioAjax.plugin_url + "includes/parts/panel/usuario.php";

                            $.ajax({
                                url: fileUrl,
                                method: "GET",
                                success: function(response) {
                                    $("#informacion").html(response);
                                    initUsuarios();
                                },
                                error: function() {
                                    $("#informacion").html("<p>Error al cargar el contenido. Intenta nuevamente.</p>");
                                }
                            });

                            $('#user-form')[0].reset();
                        }
                    });

                } else {
                    // Si la respuesta es exitosa, mostrar mensaje de éxito
                    Swal.fire({
                        title: 'Algo ha ocurrido!',
                        text: response.data.message,
                        icon: 'error',
                        confirmButtonText: 'Aceptar'
                    });
                }

            },
            error: function(xhr, status, error) {
                $('body').removeClass('actloader');
                // Si hay un error, mostrar mensaje de error
                Swal.fire({
                    title: '¡Error!',
                    text: 'Hubo un problema al procesar el formulario. Por favor intenta nuevamente.',
                    icon: 'error',
                    confirmButtonText: 'Aceptar'
                });
            }
        });
    });
});