jQuery(document).ready(function($) {

    $(document).on('click', '#crear-vehiculo', function(event) {
        event.preventDefault();

        $('#vehiculo-form')[0].reset();
        $('#wrap-vehiculos .wrap-gestion-vehiculos button[type="submit"]').text('Crear Vehículo');

        $("#wrap-vehiculos .wrap-listado-vehiculos").hide();
        $("#wrap-vehiculos .wrap-gestion-vehiculos").show();
    });

    $(document).on('click', '#wrap-vehiculos .wrap-gestion-vehiculos button[type="button"]', function(event) {
        $('#vehiculo-form')[0].reset();
        $("#vehiculo-id").text('').val('');
        $('#select-rolesusuario').val(null).trigger('change');
        $("#wrap-vehiculos .wrap-gestion-vehiculos").hide();
        $("#wrap-vehiculos .wrap-listado-vehiculos").show();
    });

    $(document).on('click', '#wrap-vehiculos .wrap-listado-vehiculos .edit-user', function(event) {

        $('#wrap-vehiculos .wrap-gestion-vehiculos button[type="submit"]').text('Editar Vehículo');
        $('#wrap-vehiculos .wrap-gestion-vehiculos .title').text('Editar Vehículo');
        $("#wrap-vehiculos .wrap-listado-vehiculos").hide();
        $("#wrap-vehiculos .wrap-gestion-vehiculos").show();

        return;

        $('body').addClass('actloader');
        var user_id = $(this).data('userid');

        $("#password").text('').val('').removeAttr("required");
        $("#user-form #user-id").val(user_id);

        // Enviar la solicitud AJAX para obtener los datos del usuario
        $.ajax({
            url: usuarioAjax.ajaxurl,
            method: 'POST',
            data: {
                action: 'load_user_data',
                user_id: user_id
            },
            success: function(response) {
                if (response.success) {

                    $('#user-id').val(user_id);
                    $('#first-name').val(response.data.first_name);
                    $('#last-name').val(response.data.last_name);
                    $('#user-email').val(response.data.email);
                    $('#select-rolesusuario').val(response.data.role).trigger('change');
                    $('#user-state').val(response.data.meta_estado).trigger('change');

                    toggleFieldsByRole(response.data.role);

                    $('#user-cedula').val(response.data.meta_cedula);
                    $('#user-telefono').val(response.data.meta_telefono);
                    $('#user-direccion').val(response.data.meta_direccion);

                    var info_pago = response.data.meta_pagos;

                    // Comprobamos si el array tiene elementos y si los campos dentro de ese objeto no están vacíos
                    if (Array.isArray(info_pago) && info_pago.length > 0) {
                        var validado = true;

                        $.each(info_pago, function(index, item) {
                            if (!item.nombre_banco || !item.no_cuenta || !item.tipo_de_cuenta) {
                                validado = false;
                                return false;
                            }
                        });

                        if (validado) {

                            $('.payment-row input').val('').text('');

                            // Llenar la primera fila con los datos del primer objeto
                            var firstPaymentRow = $('.payment-row').first();
                            firstPaymentRow.find('input[name="nombre_banco[]"]').val(info_pago[0].nombre_banco);
                            firstPaymentRow.find('input[name="no_cuenta[]"]').val(info_pago[0].no_cuenta);
                            firstPaymentRow.find('select[name="tipo_de_cuenta[]"]').val(info_pago[0].tipo_de_cuenta);

                            // Si hay más de un objeto en el array, clonar las filas adicionales y llenarlas
                            if (info_pago.length > 1) {
                                for (var i = 1; i < info_pago.length; i++) {
                                    // Clonar la última fila de pago
                                    var newRow = $('.payment-row').last().clone();

                                    // Limpiar los campos de la nueva fila
                                    newRow.find('input').val('');
                                    newRow.find('select').val('');

                                    // Llenar los campos con los datos del siguiente objeto
                                    newRow.find('input[name="nombre_banco[]"]').val(info_pago[i].nombre_banco);
                                    newRow.find('input[name="no_cuenta[]"]').val(info_pago[i].no_cuenta);
                                    newRow.find('select[name="tipo_de_cuenta[]"]').val(info_pago[i].tipo_de_cuenta);

                                    // Añadir un enlace para remover la fila
                                    newRow.append('<a href="#" class="remove-payment-row">✖</a>');

                                    // Insertar el nuevo clon en el contenedor
                                    $('#repeater-payment-fields').append(newRow);
                                }
                            }
                            $('#payment-fields-container').show();
                        }
                    } else {
                        $('.payment-row input').val('').text('');
                    }

                    $('#wrap-usuarios .wrap-gestion-usuarios button[type="submit"]').text('Editar Usuario');
                    $('#wrap-usuarios .wrap-gestion-usuarios .title').text('Editar Usuario')
                    $("#wrap-usuarios .wrap-listado-usuarios").hide();
                    $("#wrap-usuarios .wrap-gestion-usuarios").show();
                    $('body').removeClass('actloader');
                } else {
                    $('body').removeClass('actloader');
                    // Si la respuesta es exitosa, mostrar mensaje de éxito
                    Swal.fire({
                        title: 'Algo ha ocurrido!',
                        text: response.data.message,
                        icon: 'error',
                        confirmButtonText: 'Aceptar'
                    });
                }
            }
        });
    });
});