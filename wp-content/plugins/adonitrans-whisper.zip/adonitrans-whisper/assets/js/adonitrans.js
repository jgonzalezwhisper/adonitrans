jQuery(document).ready(function(e){e(document).on("click",".adonitrans-plug .formplug label i",function(t){t.preventDefault(),$ojo=e(this);t=e(this).closest("label").find("input");"password"===t.attr("type")?t.attr("type","text"):t.attr("type","password"),e(this).toggleClass("icofont-eye icofont-eye-blocked")})});
//# sourceMappingURL=adonitrans.js.map
