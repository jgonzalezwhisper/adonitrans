<?php

// Obtener lista de vehículos
add_action('wp_ajax_obtener_vehiculos', function () {
    $vehiculos = [];
    $query = new WP_Query(['post_type' => 'vehiculo', 'posts_per_page' => -1]);
    while ($query->have_posts()) {
        $query->the_post();
        $vehiculos[] = [
            'id' => get_the_ID(),
            'placa' => get_post_meta(get_the_ID(), 'placa', true),
            'modelo' => get_post_meta(get_the_ID(), 'modelo', true),
            'marca' => get_post_meta(get_the_ID(), 'marca', true),
            'estado' => get_post_meta(get_the_ID(), 'estado', true),
        ];
    }
    wp_reset_postdata();
    wp_send_json($vehiculos);
});

// Obtener datos de un vehículo
add_action('wp_ajax_obtener_vehiculo', function () {
    $vehiculo_id = intval($_POST['id']);
    $vehiculo = [
        'id' => $vehiculo_id,
        'placa' => get_post_meta($vehiculo_id, 'placa', true),
        'modelo' => get_post_meta($vehiculo_id, 'modelo', true),
        'marca' => get_post_meta($vehiculo_id, 'marca', true),
        'estado' => get_post_meta($vehiculo_id, 'estado', true),
    ];
    wp_send_json($vehiculo);
});

// Guardar o actualizar vehículo
add_action('wp_ajax_guardar_vehiculo', function () {
    $vehiculo_id = intval($_POST['id']);
    $data = [
        'placa' => sanitize_text_field($_POST['placa']),
        'modelo' => sanitize_text_field($_POST['modelo']),
        'marca' => sanitize_text_field($_POST['marca']),
        'estado' => sanitize_text_field($_POST['estado']),
    ];

    if ($vehiculo_id) {
        foreach ($data as $key => $value) {
            update_post_meta($vehiculo_id, $key, $value);
        }
    } else {
        $vehiculo_id = wp_insert_post(['post_type' => 'vehiculo', 'post_status' => 'publish']);
        foreach ($data as $key => $value) {
            update_post_meta($vehiculo_id, $key, $value);
        }
    }

    wp_send_json_success();
});

// Eliminar vehículo
add_action('wp_ajax_eliminar_vehiculo', function () {
    wp_delete_post(intval($_POST['id']), true);
    wp_send_json_success();
});

// Activar/Inactivar vehículo
add_action('wp_ajax_toggle_estado_vehiculo', function () {
    $vehiculo_id = intval($_POST['id']);
    $estado = get_post_meta($vehiculo_id, 'estado', true) === 'activo' ? 'inactivo' : 'activo';
    update_post_meta($vehiculo_id, 'estado', $estado);
    wp_send_json_success();
});
