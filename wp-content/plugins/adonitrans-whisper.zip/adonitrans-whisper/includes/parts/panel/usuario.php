<?php 
    require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');  
    if (!defined('DOING_AJAX') && !DOING_AJAX ) {
        exit('Acceso no autorizado');
    }
?>

<div id="wrap-usuarios">
    <div class="tarjeta">
        <div class="wrap-titulo">
            <h3 class="titulo">USUARIOS</h3>
            <h4 class="subtitulo">Gestiona los usuarios adscritos a la empresa</h4>
        </div>
        <p>Administra y gestiona fácilmente los usuarios registrados en tu empresa desde este panel. Mantén toda la información organizada y actualizada.</p>
    </div>

    <div class="wrap-listado-usuarios">
        <a href="#" class="button" id="crear-usuario">Crear Usuario</a>
        <table id="table-usuarios" class="display">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Rol</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (is_user_logged_in()) {
                    $current_user = wp_get_current_user();
                } else {
                    echo 'No estás autenticado.';
                }

                $is_admin = in_array('administrator', $current_user->roles);

                // Obtener usuarios, excluyendo administradores si el usuario actual no es administrador
                $args = array(
                    'role__not_in' => $is_admin ? '' : ['administrator'],  // Excluir administradores si no eres administrador
                    'orderby'      => 'user_login',
                    'order'        => 'ASC',
                );
                $users = get_users($args);

                

                foreach ($users as $user) :
                    // Excluir al usuario actual
                    if ($user->ID === $current_user->ID) {
                        continue;
                    }

                    // Obtener el nombre y apellido del usuario
                    $first_name = get_user_meta($user->ID, 'first_name', true);
                    $last_name = get_user_meta($user->ID, 'last_name', true);

                    // Obtener el rol principal del usuario
                    $roles = $user->roles;
                    $primary_role = !empty($roles) ? ucwords(str_replace('_', ' ', $roles[0])) : 'Sin rol';
                    $estado_usuario = get_field('estado_usuario', 'user_'. $user->ID);
                ?>
                    <tr>
                        <td><?= $user->ID; ?></td>
                        <td><?= $first_name . ' ' . $last_name; ?></td>
                        <td><?= $user->user_email; ?></td>
                        <td><?= $primary_role; ?></td>
                        <td class="<?= $estado_usuario; ?>"><?= $estado_usuario; ?></td>
                        <td>
                            <div class="acciones">
                                <button class="accion edit-user" data-userid="<?= $user->ID; ?>">Editar</button>
                                <button class="accion delete-user" data-userid="<?= $user->ID; ?>">Eliminar</button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="wrap-gestion-usuarios" style="display:none">
        <div class="wrap wrap-title">
            <h3 class="title">Crear Usuario</h3>
        </div>
        <form id="user-form" method="post" enctype="multipart/form-data" class="formplug">
            <input type="hidden" id="user-id" name="user-id" value="">
            <?php wp_nonce_field('create_user_action', 'create_user_nonce'); ?>

            <div class="wrap wrap-2">
                <label for="first-name">Nombres</label>
                <input type="text" id="first-name" name="first-name" required>
            </div>
            <div class="wrap wrap-2">
                <label for="last-name">Apellidos</label>
                <input type="text" id="last-name" name="last-name" required>
            </div>
            <div class="wrap wrap-2">
                <label for="user-email">Correo</label>
                <input type="email" id="user-email" name="user-email" required>
            </div>
            <div class="wrap wrap-2">
                <label for="user-roles">Rol</label>
                <select id="select-rolesusuario" name="user-roles">
                    <option value=""></option>
                    <?php
                    $roles = [
                    'comercial_1'       => 'Comercial 1',
                    'comercial_2'       => 'Comercial 2',
                    'tramites'          => 'Tramites',
                    'talento_humano'    => 'Talento Humano',
                    'operaciones_1'     => 'Operaciones 1',
                    'operaciones_2'     => 'Operaciones 2',
                    'facturacion'       => 'Facturacion',
                    'tesoreria'         => 'Tesoreria',
                    'propietario_vehiculo' => 'Propietario Vehiculo',
                    'conductor'            => 'Conductor',
                    'cliente'              => 'Cliente',
                    'empresa'              => 'Empresa',
                    ];
                    foreach ($roles as $role_key => $role_name) {
                    echo "<option value=\"$role_key\">$role_name</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="wrap">
                <label for="password">Contraseña
                    <input type="password" id="password" name="password" required>
                    <i class="icofont-eye-blocked"></i>
                </label>
                <a href="#" id="generate-password">Generar Contraseña</a>
                <div class="validapass">
                    <h3 class="subtitle">Recuerda que tu contraseña deber tener:</h3>
                    <div class="validaciones">
                        <ul>
                            <li>Entre 8 y 15 carácteres</li>
                            <li>Un número</li>
                            <li>Un carácter especial (*-_./!¿?)</li>
                            <li>Una mayúscula</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Campos adicionales generales -->
            <div class="wrap" id="extra-fields-container" style="display:none;">
                <div class="wrap">
                    <label for="user-state">Estado</label>
                    <select id="user-state" name="user-state">
                        <option value="Activo">Activo</option>
                        <option value="Inactivo">Inactivo</option>
                    </select>
                </div>
                <div class="wrap wrap-2">
                    <label for="user-cedula">Cédula</label>
                    <input type="text" id="user-cedula" name="user-cedula">
                </div>
                <div class="wrap wrap-2">
                    <label for="user-telefono">Teléfono</label>
                    <input type="text" id="user-telefono" name="user-telefono">
                </div>
                <div class="wrap">
                    <label for="user-direccion">Dirección</label>
                    <input type="text" id="user-direccion" name="user-direccion">
                </div>
                <div class="wrap">
                    <label for="user-foto">Foto Usuario</label>
                    <input type="file" id="user-foto" name="user-foto" accept="image/*">
                </div>
            </div>
            <!-- Información de pago -->
            <div class="wrap" id="payment-fields-container" style="display:none;">
                <h4>Información de Pago</h4>
                <div class="wrap" id="repeater-payment-fields">
                    <div class="wrap payment-row">
                        <div class="wrap">
                            <label>Nombre del Banco</label>
                            <input type="text" name="nombre_banco[]">
                        </div>
                        <div class="wrap">
                            <label>No. de Cuenta</label>
                            <input type="text" name="no_cuenta[]">
                        </div>
                        <div class="wrap">
                            <label>Tipo de Cuenta</label>
                            <select name="tipo_de_cuenta[]">
                                <option value="Ahorros">Ahorros</option>
                                <option value="Corriente">Corriente</option>
                            </select>
                        </div>
                    </div>
                </div>
                <a href="#" class=""id="add-payment-row">Añadir información de pago</a>
            </div>
            <div class="wrap">
                <button class="button" type="submit" name="submit-user">Crear Usuario</button>
                <button class="button" type="button" id="cancelar-vehiculo-btn">Cancelar</button>
            </div>
        </form>
    </div> 
</div>