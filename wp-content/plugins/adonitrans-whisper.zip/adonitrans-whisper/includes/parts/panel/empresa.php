<?php require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');  ?>
<div class="tarjeta">
	<div class="wrap-titulo">
		<h3 class="titulo">EMPRESA</h3>
		<h4 class="subtitulo">Gestiona los vehiculos adscritos a la empresa</h4>
	</div>
	<p>Administra y gestiona fácilmente los vehículos registrados en tu empresa desde este panel. Mantén toda la información organizada y actualizada.</p>
	<a href="#" class="button">Ver Vehiculos</a>
</div>