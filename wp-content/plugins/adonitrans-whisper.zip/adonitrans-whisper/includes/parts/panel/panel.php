<?php require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');  ?>
<div class="tarjeta">
    <div class="wrap-titulo">
        <h3 class="titulo">PANEL</h3>
        <h4 class="subtitulo">Ultimos Viajes Realizados</h4>
    </div>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam quisquam impedit fugiat debitis, illo eaque aliquam aperiam exercitationem praesentium illum maiores! Optio quisquam fugit dolor molestias deserunt odio impedit sapiente!</p>
    <a href="#" class="button">Ver Todos</a>
</div>