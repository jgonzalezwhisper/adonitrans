<?php 
    require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');  
    if (!defined('DOING_AJAX') && !DOING_AJAX ) {
        exit('Acceso no autorizado');
    }
?>

<div id="wrap-vehiculos">
    <div class="tarjeta">
        <div class="wrap-titulo">
            <h3 class="titulo">VEHÍCULOS</h3>
            <h4 class="subtitulo">Gestiona los vehículos vinculados a la empresa</h4>
        </div>
        <p>Administra y gestiona los vehículos registrados en ADONITRANS desde este panel. Mantén toda la información organizada y actualizada.</p>
    </div>

    <div class="wrap-listado-vehiculos">
        <a href="#" class="button" id="crear-vehiculo">Crear Vehículo</a>
        <table id="table-vehiculos" class="display">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Placa</th>
                    <th>Tipo</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php

                    $argsveh = [
                        'post_type' => 'vehiculo',
                        'post_status' => 'publish',
                        'posts_per_page' => -1,
                    ];

                    $query = new WP_Query($argsveh);
                ?>
                <?php if ($query->have_posts()): ?>
                    <?php while($query->have_posts()): $query->the_post();?>
                        <?php
                            $placa_vehiculo = get_field('placa_vehiculo', get_the_ID());
                            $tipo_vehiculo = get_field('tipo_de_vehiculo', get_the_ID());
                            $estado_vehiculo = get_field('estado_del_vehiculo', get_the_ID());
                        ?>
                        <tr>
                            <td><?= get_the_ID(); ?></td>
                            <td><?= $placa_vehiculo ?></td>
                            <td><?= $tipo_vehiculo; ?></td>
                            <td class="<?= $estado_vehiculo; ?>"><?= $estado_vehiculo; ?></td>
                            <td>
                                <div class="acciones">
                                    <button class="accion edit-user" data-userid="<?= $user->ID; ?>">Editar</button>
                                    <button class="accion delete-user" data-userid="<?= $user->ID; ?>">Eliminar</button>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile;wp_reset_postdata(); ?>                    
                <?php endif ?>
                    
            </tbody>
        </table>
    </div>

    <div class="wrap-gestion-vehiculos" >
        <div class="wrap wrap-title">
            <h3 class="title">Crear Vehiculos</h3>
        </div>
        <form id="vehiculo-form" method="post" enctype="multipart/form-data" class="formplug">
            <input type="hidden" id="user-id" name="user-id" value="">
            <?php wp_nonce_field('create_user_action', 'create_user_nonce'); ?>

            <div class="wrap wrap-2">
                <label for="estado_del_vehiculo">Estado</label>
                <select id="estado_del_vehiculo" name="estado_del_vehiculo">
                    <option value="Activo">Activo</option>
                    <option value="Inactivo">Inactivo</option>
                </select>
            </div>
            <div class="wrap wrap-2">
                <label for="placa_vehiculo">Placa</label>
                <input type="text" id="placa_vehiculo" name="placa_vehiculo" required>
            </div>

            <div class="wrap wrap-2">
                <label for="tipo_de_vehiculo">Tipo de vehículo</label>
                <select id="tipo_de_vehiculo" name="tipo_de_vehiculo">
                    <option value=""></option>
                    <option value="Automovil">Automovil</option>
                    <option value="Camioneta">Camioneta</option>
                    <option value="Doble Cabina">Doble Cabina</option>
                    <option value="Campero">Campero</option>
                    <option value="Van">Van</option>
                    <option value="Bus">Bus</option>
                    <option value="Buseta">Buseta</option>
                </select>
            </div>

            <div class="wrap wrap-2">
                <label for="modelo_vehiculo">Modelo</label>
                <input type="text" id="modelo_vehiculo" name="modelo_vehiculo" required>
            </div>
            <div class="wrap wrap-2">
                <label for="serial_vehiculo">Serial</label>
                <input type="email" id="serial_vehiculo" name="serial_vehiculo" required>
            </div>
            <div class="wrap wrap-2">
                <label for="chasis_vehiculo"># Chasis</label>
                <input type="email" id="chasis_vehiculo" name="chasis_vehiculo" required>
            </div>
            <div class="wrap wrap-2">
                <label for="fecha_vencimiento_soat">Fecha vencimiento SOAT (DD/MM/YYYY)</label>
                <input type="email" id="fecha_vencimiento_soat" name="fecha_vencimiento_soat" required>
            </div>
            <div class="wrap wrap-2">
                <label for="fecha_vencimiento_tecno_mecanica">Fecha Vencimiento Tecno Mecanica</label>
                <input type="email" id="fecha_vencimiento_tecno_mecanica" name="fecha_vencimiento_tecno_mecanica" required>
            </div>
            <div class="wrap wrap-2">
                <label for="propietario_de_vehiculo">Propietario de Vehículo</label>
                <select id="propietario_de_vehiculo" name="propietario_de_vehiculo">
                    <option value=""></option>
                    <?php
                        // Obtén todos los usuarios con roles específicos
                        $roles = ['conductor', 'propietario_vehiculo', 'administrador'];
                        $args = [
                            'role__in' => $roles,
                            'orderby'  => 'display_name',
                            'order'    => 'ASC',
                        ];
                        $usuarios = get_users($args);
                    ?>
                    <?php foreach ($usuarios as $usuario) : $first_name = get_user_meta($usuario->ID, 'first_name', true);?>
                        <option value="<?php echo esc_attr($usuario->ID); ?>">
                            <?= esc_html($first_name . ' - ' . $usuario->user_email); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="wrap wrap-2">
                <label for="conductor_del_vehiculo">Conductor del Vehiculo</label>
                <select id="conductor_del_vehiculo" name="conductor_del_vehiculo">
                    <option value=""></option>
                    <?php
                        // Obtén todos los usuarios con roles específicos
                        $roles = ['conductor'];
                        $args = [
                            'role__in' => $roles,
                            'orderby'  => 'display_name',
                            'order'    => 'ASC',
                        ];
                        $usuarios = get_users($args);
                    ?>
                    <?php foreach ($usuarios as $usuario) : $first_name = get_user_meta($usuario->ID, 'first_name', true);?>
                        <option value="<?php echo esc_attr($usuario->ID); ?>">
                            <?= esc_html($first_name . ' - ' . $usuario->user_email); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="wrap">
                <button class="button" type="submit" name="submit-user">Crear Usuario</button>
                <button class="button" type="button" id="cancelar-vehiculo-btn">Cancelar</button>
            </div>
        </form>
    </div> 
</div>